﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Linq;

namespace Fury
{
    #region
    class Health : Sprite, ICollectable
    {
        public Health(Texture2D t, Vector2 p) : base(t, p)
        { }

        public override void Update(GameTime gt)
        {
            position.Y += 5;

            base.Update(gt);
        }

        public void OnPickup(Laser laser)
        {

        }

        public void OnPickup(Flighter flighter)
        {
            if (flighter.Health >= 3)
                Console.WriteLine("Your health is full");
            else
                flighter.Health++;
        }

    }

    class Shield : Sprite, ICollectable
    {

        public Shield(Texture2D t, Vector2 p) : base(t, p)
        { }

        public override void Update(GameTime gt)
        {
            position.Y += 5;

            base.Update(gt);
        }


        public void OnPickup(Laser laser)
        {

        }

        public void OnPickup(Flighter flighter)
        {
            flighter.HasShield = true;
        }

    }

    class Missile : Sprite, ICollectable
    {
        public Missile(Texture2D t, Vector2 p) : base(t, p)
        { }

        public override void Update(GameTime gt)
        {
            position.Y += 5;

            base.Update(gt);
        }

        public void OnPickup(Laser laser)
        {

        }

        public void OnPickup(Flighter flighter)
        {
            if (flighter.FireBoost)
            {
                flighter.FireRateTimer = 40;
            }

            flighter.FireBoost = true;
        }
    }
    #endregion
    class eship: Sprite, ICollectable
    {
        public eship(Texture2D t, Vector2 p) : base(t, p)
        { }

        public override void Update(GameTime gt)
        {
            position.Y += 10;

            base.Update(gt);
        }

        public void OnPickup(Flighter flighter)
        {
            flighter.Health -= 25;
            
        }
    }

    class Rock: Sprite, ICollectable
    {
        public Rock(Texture2D t, Vector2 p) : base(t, p)
        { }

        public override void Update(GameTime gt)
        {
            position.Y += 5;

            base.Update(gt);
        }

        public void OnPickup(Flighter flighter)
        {
            flighter.Health -= 50;

        }
    }

}
