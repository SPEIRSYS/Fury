﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Fury
{
    class Sprite
    {
        protected Texture2D texture;
        protected Vector2 position;
        protected Rectangle rectangle;

        public Rectangle Rectangle { get => rectangle; }

        public Sprite(Texture2D t, Vector2 p)
        {
            texture = t;
            position = p;
            rectangle = new Rectangle(0, 0, texture.Width, texture.Height);
        }

        public virtual void Update(GameTime gt) //Since its virtual this means it can be overriden in a derrived class
        {
            rectangle.X = (int)position.X;
            rectangle.Y = (int)position.Y;
        }

        public virtual void Draw(SpriteBatch sb)
        {
            
            sb.Draw(texture, rectangle, Color.White);
            
        }

    }
}
