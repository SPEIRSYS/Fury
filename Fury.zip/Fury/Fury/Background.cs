﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Linq;

namespace Fury
{
    class Background
    {
        public Texture2D texture;
        public Vector2 bgPos1, bgPos2;
        public int speed;

        public Background()
        {
            bgPos1 = new Vector2(0, 0);
            bgPos2 = new Vector2(0, -1400);
            speed = 5;
        }

        public void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("bg3");
        }

        public void Draw(SpriteBatch spritebatch)
        {
            spritebatch.Draw(texture, bgPos1, Color.White);
            spritebatch.Draw(texture, bgPos2, Color.White);
        }
        
        public void Update(GameTime gameTime)
        {
            bgPos1.Y = bgPos1.Y + speed;
            bgPos2.Y = bgPos2.Y + speed;

            if (bgPos1.Y >= 1400)
            {
                bgPos1.Y = 0;
                bgPos2.Y = -1400;
            }
        }
    }
}
