﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Linq;

namespace Fury
{
    public class Game1 : Game
    {

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        // ---------------- FLIGHTER ----------------
        Flighter flighter;
        SpriteFont eFont;
        Laser laser;
        Texture2D hTex;
        Texture2D fTex;
        Texture2D lTex;
        Texture2D sTex;
        Texture2D eTex;
        Texture2D enemyText;
        Texture2D screen01;
        Texture2D screen02;
        Texture2D damScreen;
        Vector2 startPos;

        Background b = new Background();
        Texture2D hPU;
        Texture2D sPU;
        Texture2D mPU;
        Song song;

        Texture2D bg;

        Random random = new Random();
        Random r = new Random();
        
        List<ICollectable> collectables = new List<ICollectable>();
        List<ICollectable> eCollectables = new List<ICollectable>();

        public float time;
        public int totalScore = 0; //Used to set the score value to 0
        float collectableTimer;
        float eCollectableTimer;

        public enum GameState { MainMenu, MainGame, GameOver, Paused } //Here we have created different states for our game using GameState
        public GameState gamestate = GameState.MainMenu; // Sets the default gamestate that shows when the game loads
        public Vector2 cameraAnchor;
        public Rectangle screenBounds { get; private set; }
        int screenWidth;
        int screenHeight;
        int nextValue;
        
        #region Game1()
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
        }
        #endregion

        #region Initalize
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            cameraAnchor = new Vector2(graphics.PreferredBackBufferWidth / 2, graphics.PreferredBackBufferHeight / 2);
            screenBounds = new Rectangle((int)(cameraAnchor.X - (graphics.PreferredBackBufferWidth / 2)),
                            (int)(cameraAnchor.Y - (graphics.PreferredBackBufferHeight / 2)),
                            graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);

            int nextValue = r.Next(3, 4); // Returns a random number from 0-99

            base.Initialize();
        }
        #endregion

        #region LoadContent
        protected override void LoadContent()
        {

            spriteBatch = new SpriteBatch(GraphicsDevice);

            eFont = Content.Load<SpriteFont>("eFont"); //loads in the font used for the game over text 

            fTex = Content.Load<Texture2D>("td-sh");

            startPos = new Vector2(GraphicsDevice.Viewport.Width / 2 - (fTex.Width / 2),
                (GraphicsDevice.Viewport.Height - fTex.Height) - 10);

            lTex = Content.Load<Texture2D>("laser2");

            sTex = Content.Load<Texture2D>("elec-shield");

            sPU = Content.Load<Texture2D>("ShieldPickUp");

            mPU = Content.Load<Texture2D>("MissilePickUp");

            hTex = Content.Load<Texture2D>("healthBar");

            eTex = Content.Load<Texture2D>("rock");

            enemyText= Content.Load<Texture2D>("eShip");

            screen01 = Content.Load<Texture2D>("ST Screen");

            screen02 = Content.Load<Texture2D>("GOScreen");

            damScreen = Content.Load<Texture2D>("dmg");

            this.song = Content.Load<Song>("Cloudberry High");
            MediaPlayer.Volume -= 0.001f;
            //  MediaPlayer.Play(song);

           

            flighter = new Flighter(lTex, fTex, sTex, hTex, startPos);
            b.LoadContent(Content);


        }
        #endregion
        /*
               protected void Volume(object sender, EventArgs e)
                {
                    // 0.0f is silent, 1.0f is full volume
                    MediaPlayer.Volume -= 1f;
                    MediaPlayer.Play(song);
                }
                */

        #region Update
        protected override void Update(GameTime gameTime)
        {

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState ks = Keyboard.GetState();

            Window.Title = "Health: " + flighter.Health;
            switch (gamestate)
            {
                case GameState.MainMenu:

                    totalScore = 0;
                    time = 0;
                    
                    if (ks.IsKeyDown(Keys.Space)) 
                    {
                        gamestate = GameState.MainGame;
                        flighter.Health = 200;
                    }

                    break;

                case GameState.MainGame:

                    time += (float)gameTime.ElapsedGameTime.TotalSeconds;
                    totalScore += (int)gameTime.ElapsedGameTime.Milliseconds / 10;
                 
                    collectableTimer += gameTime.ElapsedGameTime.Milliseconds;
                    eCollectableTimer += gameTime.ElapsedGameTime.Milliseconds;

                    if (collectableTimer > 1000)
                    {
                        AddCollectable();
                        AddeCollectable();
                        collectableTimer = 0;
                    }

                    if (collectableTimer > 940)
                    {
                        AddeCollectable();
                        
                    }
                    
                    foreach (ICollectable c in collectables)
                    {
                        Sprite s = c as Sprite;
                        s.Update(gameTime);

                        if (s.Rectangle.Intersects(flighter.Rectangle))
                        {
                            c.OnPickup(flighter);
                            collectables.Remove(c);
                            break;
                        }
                    }

                    foreach (ICollectable e in eCollectables)
                    {
                        Sprite s = e as Sprite;
                        s.Update(gameTime);

                        if (s.Rectangle.Intersects(flighter.Rectangle))
                        {
                            e.OnPickup(flighter);
                            collectables.Remove(e);
                            break;
                        }
                    }

                    if (flighter.Health <= 0)
                    {
                        gamestate = GameState.GameOver;
                    }
                    
                    flighter.Update(gameTime);
                    b.Update(gameTime);
                    break;

                case GameState.GameOver:

                    if (ks.IsKeyDown(Keys.Enter))
                    {
                        gamestate = GameState.MainMenu;
                        flighter.Health = 200;
                    }
                    break;
            }
            base.Update(gameTime);
        }
        #endregion

        #region AddCollectable
         void AddCollectable()
        {
            Random rand = new Random();
            

            int randomX = rand.Next(0, 1200);
            int spawnY = Window.ClientBounds.Y - 300;

            Vector2 spawnpos = new Vector2(randomX, spawnY);

            int collectable = 0;
            Vector2 spawnPos = new Vector2(randomX, spawnY);

          
            switch (collectable)
            {
               
                case 0:
                    collectables.Add(new eship(eTex, spawnPos));
                    break;
            }
        }
        #endregion

        #region Add eCollectable
        void AddeCollectable()
        {
            Random rand = new Random();
            
            int randomX = rand.Next(Window.ClientBounds.X, Window.ClientBounds.Width - 100);
            int spawnY = Window.ClientBounds.Y - 300;

            Vector2 spawnpos = new Vector2(randomX, spawnY);

            
            int eCollectable = 0;

            Vector2 spawnPos = new Vector2(randomX, spawnY);


            switch (eCollectable)
            {

                case 0:
                    collectables.Add(new eship(enemyText, spawnPos));
                    break;
            }
        }

        #endregion
        #region Draw
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            switch (gamestate)
            {
                case GameState.MainMenu:
                    spriteBatch.Draw(screen01, new Vector2(0, 0), Color.White);
                   
                    spriteBatch.DrawString(eFont, "WASD to move. Hold out for as long as you can.", new Vector2(325, 100), Color.White);
                    break;

                case GameState.MainGame:

                    b.Draw(spriteBatch);

                    foreach (ICollectable c in collectables)
                    {
                        Sprite s = c as Sprite;
                        s.Draw(spriteBatch);
                    }

                    foreach (ICollectable e in eCollectables)
                    {
                        Sprite s = e as Sprite;
                        s.Draw(spriteBatch);
                    }

                    #region player info

                    spriteBatch.DrawString(eFont, "Score: " + totalScore.ToString("0.00"), new Vector2(800, 0), Color.White);
                    spriteBatch.DrawString(eFont, "HP: " + flighter.Health.ToString("0.00"), new Vector2(50, 0), Color.White);
                    #endregion

                    flighter.Draw(spriteBatch);

                    #region Red Outline
                    if (flighter.Health <= 100)
                    { spriteBatch.Draw(damScreen, new Vector2(0, 0), Color.White * 0.15f); }

                    if (flighter.Health <= 75)
                    { spriteBatch.Draw(damScreen, new Vector2(0, 0), Color.White * 0.33f); }

                    if (flighter.Health <= 50)
                    { spriteBatch.Draw(damScreen, new Vector2(0, 0), Color.White * 0.5f); }

                    if (flighter.Health <= 25)
                    { spriteBatch.Draw(damScreen, new Vector2(0, 0), Color.White * 0.75f); }
                    #endregion
                    // enemy.Draw(spriteBatch);

                    

                    base.Draw(gameTime);
                    break;

                case GameState.GameOver:

                    spriteBatch.Draw(screen02, new Vector2(0, 0), Color.White);
                    spriteBatch.DrawString(eFont, "Your Total Score Was...", new Vector2(510, 100), Color.White);
                    spriteBatch.DrawString(eFont, totalScore.ToString("0.00") + " points", new Vector2(575, 150), Color.White);

                    break;
            }
            spriteBatch.End();
        }
        #endregion
    }
}