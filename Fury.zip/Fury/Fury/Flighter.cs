﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Fury
{
    class Flighter : Sprite
    {

        // ---------------- FIELDS ----------------
        private float shootDelay;
        private Texture2D lTex;
        private Texture2D shield;
        private bool canShoot = true;
        private Rectangle shieldRect; 
        private Rectangle healthRectangle;
        private float fireRate = 500;
        private Vector2 healthBarPos;
        private Texture2D hBar;

        // ---------------- PROPERTIES ----------------
        public int Health { get; set; }

        public List<Laser> LaserList { get; set; } = new List<Laser>();

        public bool HasShield { get; set; }
        public bool FireBoost { get; set; }
        public float FireRateTimer { get; set; }

        // ---------------- FLIGHTER CONSTRUCTOR ----------------

        public Flighter(Texture2D l, Texture2D t, Texture2D s, Texture2D h,  Vector2 p) : base(t, p)
        { 
            lTex = l;
            shield = s;
            hBar = h;
            Health = 200;
            healthBarPos = new Vector2(50, 50);
        }

        public void LoadContent(ContentManager Content)
        {
          
        }

        public Flighter(Texture2D t, Vector2 p) : base (t, p)
        {

        }
        #region Move()
        private void Move()
        {
            KeyboardState ks = Keyboard.GetState();

            if (ks.IsKeyDown(Keys.A))
                position.X -= 7;

            if (ks.IsKeyDown(Keys.D))
                position.X += 7;

            if (ks.IsKeyDown(Keys.W))
                position.Y -= 7;

            if (ks.IsKeyDown(Keys.S))
                position.Y += 7;
        }
        #endregion

        #region Update
        public override void Update(GameTime gt)
        {
            KeyboardState ks = Keyboard.GetState();

            Move();
            
            //Shooting
            //Shoot(gt);

            //Setting Rect for health bar

            healthRectangle = new Rectangle((int)healthBarPos.X, (int)healthBarPos.Y, Health, 25);

            foreach (Laser l in LaserList)
            {
                if(l.Lifetime <= 0)
                {
                    LaserList.Remove(l);
                    break;
                }

                l.Update(gt);
            }

       
            base.Update(gt);
        }

        #endregion

        //shooting method
        #region 
            /*
        Shoot, Origin, FireRate
        private void Shoot(GameTime gt)
        {
            KeyboardState ks = Keyboard.GetState();

            if (ks.IsKeyDown(Keys.Space))
            {
                if (canShoot)
                {
                    LaserList.Add(new Laser(lTex, Origin(lTex)));
                    canShoot = false;
                }

                shootDelay += gt.ElapsedGameTime.Milliseconds;

                if (shootDelay > fireRate)
                {
                    shootDelay = 0;
                    canShoot = true;
                }
            }
        }

        private Vector2 Origin(Texture2D tex)
        {
            return new Vector2(rectangle.X + (rectangle.Width / 2 - (tex.Width / 2)), (rectangle.Y - tex.Height));
        }
/*
        private void FireRate(GameTime gt)
        {
            //We check if HasIncreasedFire is true. If so, we set the
            //fire-rate to the value we want, then begin incrementing
            //the timer. If the timer reaches 5 seconds, we reset the
            //fire-rate, reset the timer and turn HasIncreasedFire to
            //false.

            if (FireBoost)
            {
                fireRate = 50;
                FireRateTimer += gt.ElapsedGameTime.Milliseconds;

                if (FireRateTimer > 5000)
                {
                    fireRate = 400;
                    FireRateTimer = 0;
                    FireBoost = false;
                }
            }
        }
*/
        #endregion

        public override void Draw(SpriteBatch sb)
        {
            foreach (Laser l in LaserList)
                l.Draw(sb);

            base.Draw(sb);
                        
            sb.Draw(hBar, healthRectangle, Color.White);            
        }

    }
}
